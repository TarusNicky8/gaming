const gameContainer = document.getElementById("game-container");
const scoreDisplay = document.getElementById("score");

const gridSize = 20;
let snake = [{ x: 0, y: 0 }];
let food = { x: 200, y: 200 };
let direction = { x: gridSize, y: 0 };
let score = 0;
let gameInterval;

// Create food
function createFood() {
    food.x = Math.floor(Math.random() * 20) * gridSize;
    food.y = Math.floor(Math.random() * 20) * gridSize;
}

// Draw game elements
function draw() {
    gameContainer.innerHTML = "";

    // Draw snake
    snake.forEach((segment) => {
        const snakeElement = document.createElement("div");
        snakeElement.style.left = `${segment.x}px`;
        snakeElement.style.top = `${segment.y}px`;
        snakeElement.classList.add("snake");
        gameContainer.appendChild(snakeElement);
    });

    // Draw food
    const foodElement = document.createElement("div");
    foodElement.style.left = `${food.x}px`;
    foodElement.style.top = `${food.y}px`;
    foodElement.classList.add("food");
    gameContainer.appendChild(foodElement);
}

// Move snake
function moveSnake() {
    const head = { x: snake[0].x + direction.x, y: snake[0].y + direction.y };
    snake.unshift(head);

    // Check for collisions
    if (head.x === food.x && head.y === food.y) {
        score++;
        scoreDisplay.textContent = score;
        createFood();
    } else {
        snake.pop();
    }

    // Check wall or self collision
    if (
        head.x < 0 ||
        head.x >= gameContainer.offsetWidth ||
        head.y < 0 ||
        head.y >= gameContainer.offsetHeight ||
        snake.slice(1).some((segment) => segment.x === head.x && segment.y === head.y)
    ) {
        alert(`Game Over! Final Score: ${score}`);
        clearInterval(gameInterval);
        resetGame();
    }
}

// Change direction
document.addEventListener("keydown", (event) => {
    if (event.code === "ArrowUp" && direction.y === 0) direction = { x: 0, y: -gridSize };
    if (event.code === "ArrowDown" && direction.y === 0) direction = { x: 0, y: gridSize };
    if (event.code === "ArrowLeft" && direction.x === 0) direction = { x: -gridSize, y: 0 };
    if (event.code === "ArrowRight" && direction.x === 0) direction = { x: gridSize, y: 0 };
});

// Reset game
function resetGame() {
    snake = [{ x: 0, y: 0 }];
    direction = { x: gridSize, y: 0 };
    score = 0;
    scoreDisplay.textContent = score;
    createFood();
    gameInterval = setInterval(() => {
        moveSnake();
        draw();
    }, 200);
}

// Start game
createFood();
resetGame();
